const s = ( p ) => {

var fonsimatge;
var p1;
var p2;
var ball;
var xBallChange = 5;
var yBallChange = 5;
var playerSprite;
var ballSprite;
var  dificultat;
var canço;
var soInici;
var pista;
var punts;
var nombre;
var apellidos;
var nif;
var edad;
var gmail;
// Player1('jugador1',p);
p.preload = function() {

    p1 = new Player("jugador1",p);
    p2 = new Player("jugador2",p);
    ball = new Ball(p);
    p.soundFormats('mp3', 'ogg');
    dificultat = window.localStorage.getItem("dificultat");
    canço = window.localStorage.getItem("canço");
    pista = window.localStorage.getItem("pista");
    punts = window.localStorage.getItem("punts");
    nom = window.localStorage.getItem("nom");
    apellidos = window.localStorage.getItem("apellidos");
    nif = window.localStorage.getItem("nif");
    edad = window.localStorage.getItem("edad");
    email = window.localStorage.getItem("email");
    //soInici = p.loadSound("sons/pacman-song.mp3");
  //  fontsimatge = p.loadImage("images/pista.jpg");
    p.pista();
    p.nivell();
    p.canço();


      try {


      //  font = loadFont('assets/SourceSansPro-Regular.otf');
    }catch (Execption) { // non-standard
         console.log("Error al cargar les imatges");
      }
    }

    p.setup = function() {
      p.createCanvas(1100,700);
      ball.move(p);
      soInici.play();


      //ball.colliderPlayer(p,p1);
    }

    p.draw = function(){
          p.background(fontsimatge);
          p.drawSprites();

          if( ball.bordes(p) ==1){
            //punt jugador 1
              p1.punts = p1.punts +1;
              p.reiniciarPunto();
          }
          else if( ball.bordes(p) ==2){
              p2.punts = p2.punts +1;
              p.reiniciarPunto();
          }else if(ball.bordes(p) == 3){
          
          }

          ball.colliderPlayer(p,p1);
          ball.colliderPlayer(p,p2);
          document.getElementById("puntsP1").innerHTML = p1.punts;
          document.getElementById("puntsP2").innerHTML = p2.punts;
          document.getElementById("temps").innerHTML = p1.temps;








          if (p.frameCount % 60 == 0 && p1.temps > 0) { // if the frameCount is divisible by 60, then a second has passed. it will stop at 0
              p1.temps++;

          }

          p.guanyar();







    }

    p.reiniciarPunto = function(p){

        ball.posicioPilotaInicial();
        p1.posicioJugadorsInicial("jugador1");
        p2.posicioJugadorsInicial("jugador2");


    }


p.keyPressed = function(){

    try{

    if(p.keyCode == p.LEFT_ARROW){
console.log("Esquerra");
        p2.moveLeftPlayer2();

    }
    if(p.keyCode == p.RIGHT_ARROW){
        p2.moveRightPlayer2();

    }
    if(p.keyCode == p.UP_ARROW){
        p2.moveUp();
          }
    if(p.keyCode == p.DOWN_ARROW){
        p2.moveDown();
      }
    if(p.key == 'a'){

        p1.moveLeftPlayer1();

    }
    if(p.key == 'd'){
        p1.moveRightPlayer1();



    }
    if(p.key == 'w'){
        console.log("es mou")
        p1.moveUp();


    }
    if(p.key == 's'){
        p1.moveDown();



    }

    }catch (err) { // non-standard
       console.log("Error el moviment del player1",err);
    }

}
p.ajuda = function(){
    alert("Anar cap a dal jugador 1:   la tecla w"+ "\n" + "Anar a l'esquerra jugador 1: la tecla a" + "\n" + "Anar a la dreta jugador 1: la tecla d" + "\n" + "Anar cap abaix jugador1: la tecla s" + "\n" + "Anar cap a dal jugador2:   la tecla del cursor de dalt"+ "\n" + "Anar a l'esquerra jugador 2: la tecla de cursor esquerra" + "\n" + "Anar a la dreta jugador 2: la tecla del cursor dret" + "\n" + "Anar cap abaix jugador2: la tecla de abaix dels cursors" + "\n" + "Guanyara el primer jugador que faci 5 punts.");

}
p.informacio = function(){
    alert("El navegador que se está utilizando es Firefox"  + navigator.appVersion + "\n" +document.lastModifyed+"\n" +navigator.userAgent +"\n"+ window.location.pathname + "\n" + navigator.language);

}
p.credits = function(){
    alert("Joc creat per Pol Júlvez Torà" + "\n" + "En motiu de la UF3 de l'assignatura m6");

}
p.nivell = function(){
  if(dificultat == "facil"){
      ball.speed = 5;
   }
  if(dificultat == "normal"){
       ball.speed = 15;
  }
  if(dificultat == "dificil"){
       ball.speed = 25;
  }
}
p.canço = function(){
  if(canço == "tennis"){
      soInici = p.loadSound("sons/canço1.mp3");
   }
  if(canço == "mii"){
       soInici = p.loadSound("sons/canço2.mp3");
  }
  if(canço == "sonic"){
       soInici = p.loadSound("sons/canço3.mp3");
  }


}
p.pista = function(){
  if(pista == "pista1"){
    fontsimatge = p.loadImage("images/pista.jpg");
  }
  if(pista == "espai"){
       fontsimatge = p.loadImage("images/pista2.jpeg");
  }
  if(pista == "selva"){
      fontsimatge = p.loadImage("images/pista3.jpg");
  }

}
p.guanyar = function(){
      if(punts == "cinc"){
          if(p1.punts == 5){
                alert("Has guanyat jugador 1");
                window.localStorage.setItem("score",p1.score);
                p.noLoop();
                var opcion = confirm( "Nom: " + nom + "\n" + "Email: " + email + "\n"  +
                            "Cognoms: " + apellidos + "\n" +
                            "Edat: " + edad + "\n" +
                            "Nif: " + nif + "\n" +

                   "Vols tornar a jugar");
                if (opcion == true) {
                    window.location.reload();
                 } else {
                   mensaje = "Has clickado Cancelar";
              }
          }


          if(p2.punts == 5){
                alert("Has guanyat jugador 2");
                window.localStorage.setItem("score",p2.score);
                p.noLoop();
                var opcion = confirm("Vols tornar a jugar");
                if (opcion == true) {
                    window.location.reload();
                 } else {
                   mensaje = "Has clickado Cancelar";
              }
          }
    }
    if(punts == "once"){
          if(p1.punts == 11){
                alert("Has guanyat jugador 1");
                window.localStorage.setItem("score",p1.score);
                p.noLoop();
                var opcion = confirm( "Nom: " + nom + "\n" + "Email: " + email + "\n"  +
                            "Cognoms: " + apellidos + "\n" +
                            "Edat: " + edad + "\n" +
                            "Nif: " + nif + "\n" +

                   "Vols tornar a jugar");
                if (opcion == true) {
                    window.location.reload();
                 } else {
                   mensaje = "Has clickado Cancelar";
              }
          }


          if(p2.punts == 11){
                alert("Has guanyat jugador 2");
                window.localStorage.setItem("score",p2.score);
                p.noLoop();
                var opcion = confirm("Vols tornar a jugar");
                if (opcion == true) {
                    window.location.reload();
                 } else {
                   mensaje = "Has clickado Cancelar";
              }
          }
    }
    if(punts == "vinticuatre"){
          if(p1.punts == 24){
                alert("Has guanyat jugador 1");
                window.localStorage.setItem("score",p1.score);
                p.noLoop();
                var opcion = confirm( "Nom: " + nom + "\n" + "Email: " + email + "\n"  +
                            "Cognoms: " + apellidos + "\n" +
                            "Edat: " + edad + "\n" +
                            "Nif: " + nif + "\n" +

                   "Vols tornar a jugar");
                if (opcion == true) {
                    window.location.reload();
                 } else {
                   mensaje = "Has clickado Cancelar";
              }
          }


          if(p2.punts == 24){
                alert("Has guanyat jugador 2");
                window.localStorage.setItem("score",p2.score);
                p.noLoop();
                var opcion = confirm("Vols tornar a jugar");
                if (opcion == true) {
                    window.location.reload();
                 } else {
                   mensaje = "Has clickado Cancelar";
              }
          }
    }

  }


}



let myp5 = new p5(s, 'joc');
